import React from 'react';

const ManageOrder = () => {
    return (
        <div>
            <h2 className="text-4xl">Manage Order</h2>
        </div>
    );
};

export default ManageOrder;