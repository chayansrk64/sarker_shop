import React from 'react';

const About = () => {
    return (
       <div className='mt-16'>
            <h2 className='text-4xl'>About Us</h2>
       </div>
    );
};

export default About;